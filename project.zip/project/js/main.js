let stars = document.getElementById('stars');
let moon = document.getElementById('moon');
let mountain3 = document.getElementById('mountain3');
let mountain4 = document.getElementById('mountain4');
let river = document.getElementById('river');
let boat6 = document.getElementById('boat6');
let nouvil = document.querySelector('nouvil');
window.onscroll = function () {
    let value = scrollY;
    stars.style.left = value + 'px';
    
}

